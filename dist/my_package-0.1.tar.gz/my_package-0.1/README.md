#my_package
This is a library to learn how to create packages using VSC

##to build this package locally
'python setup.py sdist'

##installing this package from Github
'pip install git + URL from github'

##updating the package from github
'pip install --upgrade git + URL from github'